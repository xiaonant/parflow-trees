#include "trees_wrapper.h"
//#include "treeclass.h"
#include "trees.h"
//void * __gxx_personality_v0 ;
///but not sure about parallel yet
extern "C" {
    
    CTest * test_new(int i) {
        trees *t = new trees(i);
        
        return (CTest *)t;
    }
    
    void test_testfunc( CTest *test) {
        trees *t = (trees *)test;
        t->testfunc();
    }
    
    void test_delete(CTest *test) {
        trees *t = (trees *)test;
        
        delete t;
    }
    
    void test_advanceInOneTimeStep(double *pp,  //pressure
                              double *sp, //saturation
                              double *et, //??
                              double *ms, //mask
                              double *po_dat, //porosity
				double *soil_kmax_dat, //VG soil kmax	-- new
				double *soil_a_dat, //VG soil a	-- new
				double *soil_n_dat, //VG soil n	-- new
                              double *dz_dat, //??
                              //time-recording?? calling parf less frequent than trees??
                              double istep,//need to check how these modified
                              double cdt,
                              double t,
                              double start_time,
                              
                              double dx,double dy, double dz,
                              int nx,int ny, int nz,  //original grid; while grid with ghost would be (nx+2)*(ny+2)*(nz+2)
                              int ip, int p, int q, int r, int gnx, int gny, int rank, //maybe for parallel?
                              
                              double * rad_data,
                              //double * sw_data,
                              //double * lw_data,
                              double * prcp_data,
                              double * tas_data,
                              double * wind_data,
                              //double * u_data,
                              //double * v_data,
                              double * patm_data,
                              double * vpd_data, //forcing
                              double *co2_data,
                              double * vegemap,
                              double * scalarmap,

                              double year,
                              double jday,
                              double time,
				  double lai_tai,
                              
                              double * qflx_soi,  //soil evap
                              double * qflx_eveg, //canopy evap
                              double * qflx_tveg, //transpiration
                              double * qflx_Ecrit, //critical transpiration
			
                              double * qflx_infil, //precip after infiltration
                                   CTest *test){
        
        ((trees*)test)->advanceInOneTimeStep(pp,  //pressure
                                         sp, //saturation
                                         et, //??
                                         ms, //mask
                                         po_dat, //porosity
					soil_kmax_dat, //VG soil kmax	-- new
					soil_a_dat, //VG soil a	-- new
					soil_n_dat, //VG soil n	-- new

                                         dz_dat, //??
                                         //time-recording?? calling parf less frequent than trees??
                                         istep,//need to check how these modified
                                         cdt,
                                         t,
                                         start_time,
                                         
                                         dx, dy, dz,
                                         nx, ny, nz,  //original grid; while grid with ghost would be (nx+2)*(ny+2)*(nz+2)
                                         ip, p, q, r, gnx, gny, rank, //maybe for parallel?
                                         
                                         rad_data,
                                         //double * sw_data,
                                         //double * lw_data,
                                         prcp_data,
                                         tas_data,
                                         wind_data,
                                         //double * u_data,
                                         //double * v_data,
                                         patm_data,
                                         vpd_data, //forcing
                                         co2_data,
                                         vegemap,
                                         scalarmap,

                                         year,
                                         jday,
                                         time,
						lai_tai,
                                         
                                         qflx_soi,  //soil evap
                                         qflx_eveg, //canopy evap
                                         qflx_tveg, //transpiration
                             		qflx_Ecrit, //critical transpiration

                                         qflx_infil //precip after infiltration
                                         );

    }
    
}


////////////OR another solution
/*
 void* getFoo(int32_t a){
    Foo *out = new Foo(a);
    return ((void*)out);
}

void destroyFoo(void* foo){
   delete (((Foo*)foo));
}

void printString(void *foo){
    std::string s = ((Foo*)foo)->toString();
    std::cout << s;
}
*/