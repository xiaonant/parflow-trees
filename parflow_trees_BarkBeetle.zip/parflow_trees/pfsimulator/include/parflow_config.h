/* include/parflow_config.h.  Generated from parflow_config.h.in by configure.  */
/*
 * File:        $URL: svn+ssh://tux262.llnl.gov/usr/casc/samrai/repository/PARFLOW/trunk/config/PARFLOW_config.h.in $
 * Package:     PARFLOW autoconf
 * Copyright:   (c) 1997-2008 Lawrence Livermore National Security, LLC
 * Revision:    $LastChangedRevision: 2180 $
 * Modified:    $LastChangedDate: 2008-05-05 16:49:32 -0700 (Mon, 05 May 2008) $
 * Description: PARFLOW configuration file
 */  

/*
*************************************************************************
*                                                                       *
* IMPORTANT NOTE:  This file may be included in C source and/or         *
*                  header files.  Thus, all syntax, including           *
*                  comments must be standard C.                         *
*                                                                       *
*************************************************************************
*/

#ifndef included_PARFLOW_config
#define included_PARFLOW_config

/*
 * AMPS options
 */
#ifndef AMPS
#define AMPS mpi1
#endif

#ifndef AMPS_SPLIT_FILE
/* #undef AMPS_SPLIT_FILE */
#endif

#ifndef PF_TIMING
#define PF_TIMING 1
#endif

/*
 * Misc machine config options
 */

#ifndef CASC_HAVE_GETTIMEOFDAY
#define CASC_HAVE_GETTIMEOFDAY 1
#endif

#ifndef CASC_HAVE_BIGENDIAN
/* #undef CASC_HAVE_BIGENDIAN */
#endif

/*
 * X11 libraries
 */

#ifndef LACKS_X11
#define LACKS_X11 1
#endif

/*
 * Fortran compiler name mangling
 */

/* #undef FORTRAN_DOUBLE_UNDERSCORE */
/* #undef FORTRAN_UNDERSCORE */
/* #undef FORTRAN_CAPS */
/* #undef FORTRAN_NO_UNDERSCORE */

#ifndef HAVE_CLM
#define HAVE_CLM 1
#endif

#ifndef HAVE_OAS3
/* #undef HAVE_OAS3 */
#endif

/*
 * HDF5 common data format library
 */

#ifndef HAVE_HDF5
/* #undef HAVE_HDF5 */
#endif

/*
 * cegdb
 */

#ifndef HAVE_CEGDB
/* #undef HAVE_CEGDB */
#endif

/*
 * SAMRAI
 */

#ifndef HAVE_SAMRAI
/* #undef HAVE_SAMRAI */
#endif

/*
 * SLURM
 */

#ifndef HAVE_SLURM
/* #undef HAVE_SLURM */
#endif


/*
 * Silo 
 */

#ifndef HAVE_SILO
#define HAVE_SILO 1
#endif

/*
 * Hypre 
 */

#ifndef HAVE_HYPRE
#define HAVE_HYPRE 1
#endif

#ifndef PARFLOW_HYPRE_VERSION_MAJOR
#define PARFLOW_HYPRE_VERSION_MAJOR 2
#endif

#ifndef PARFLOW_HYPRE_VERSION_MINOR
#define PARFLOW_HYPRE_VERSION_MINOR 9
#endif

#ifndef PARFLOW_HYPRE_VERSION_PATCH
#define PARFLOW_HYPRE_VERSION_PATCH 0b
#endif

/*
 * Building with XDR
 */
#ifndef HAVE_XDR
/* #undef HAVE_XDR */
#endif

/*
 * MPI parallel message passing package
 */

#ifndef HAVE_MPI
#define HAVE_MPI 1
#endif

/*
 * Sundials solver package
 */

#ifndef HAVE_SUNDIALS
/* #undef HAVE_SUNDIALS */
#endif

/* HAVE_MALLOC_H */
#define HAVE_MALLOC_H 1

/* Define if you have the 'mallinfo' function. */
#define HAVE_MALLINFO 1

/*
 * Prevent inclusion of mpi C++ bindings in mpi.h includes.
 * This is done in here rather than amps.h since other
 * files include MPI.h.
 */
#ifndef MPI_NO_CPPBIND
#define MPI_NO_CPPBIND
#endif

#ifndef MPICH_SKIP_MPICXX
#define MPICH_SKIP_MPICXX
#endif

#ifndef OMPI_SKIP_MPICXX
#define OMPI_SKIP_MPICXX
#endif


#endif
