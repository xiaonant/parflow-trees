#!/bin/sh

../../misc/bin/depend

