/*BHEADER**********************************************************************

  Copyright (c) 1995-2009, Lawrence Livermore National Security,
  LLC. Produced at the Lawrence Livermore National Laboratory. Written
  by the Parflow Team (see the CONTRIBUTORS file)
  <parflow@lists.llnl.gov> CODE-OCEC-08-103. All rights reserved.

  This file is part of Parflow. For details, see
  http://www.llnl.gov/casc/parflow

  Please read the COPYRIGHT file or Our Notice and the LICENSE file
  for the GNU Lesser General Public License.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License (as published
  by the Free Software Foundation) version 2.1 dated February 1999.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the IMPLIED WARRANTY OF
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the terms
  and conditions of the GNU General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
  USA
**********************************************************************EHEADER*/

/******************************************************************************
 * Tai --- C to trees c++ interfacing macros
 *
 *****************************************************************************/

//#ifdef __cplusplus
//class Foo{
//    public:
//    Foo(int32_t a = 4);
//    ~Foo();
//    std::string toString();
//  private:
//    int32_t k;
//    
//    
//    ///Tai wonder if this place can just be #include <tree.h>
//};
//
// #endif
//
//
//
//
//
//#ifdef __cplusplus
//extern "C" {
//#endif
//    void*  getFoo(int32_t a);
//    void  destroyFoo(void *foo);
//    void printString(void *foo);
//#ifdef __cplusplus
//}
//#endif
//
//

/**another solution************************************************/

typedef void CTest;

#ifdef __cplusplus
extern "C" {
#endif
    CTest * test_new(int i);
    void test_testfunc(CTest *t);
    void test_delete(CTest *t);
    
    void test_advanceInOneTimeStep(double *pp,  //pressure
                              double *sp, //saturation
                              double *et, //??
                              double *ms, //mask
                              double *po_dat, //porosity
				double *soil_kmax_dat, //VG soil kmax	-- new
				double *soil_a_dat, //VG soil a	-- new
				double *soil_n_dat, //VG soil n	-- new

                              double *dz_dat, //??
                              //time-recording?? calling parf less frequent than trees??
                              double istep,//need to check how these modified
                              double cdt,
                              double t,
                              double start_time,
                              
                              double dx,double dy, double dz,
                              int nx,int ny, int nz,  //original grid; while grid with ghost would be (nx+2)*(ny+2)*(nz+2)
                              int ip, int p, int q, int r, int gnx, int gny, int rank, //maybe for parallel?
                              
                              double * rad_data,
                              //double * sw_data,
                              //double * lw_data,
                              double * prcp_data,
                              double * tas_data,
                              double * wind_data,
                              //double * u_data,
                              //double * v_data,
                              double * patm_data,
                              double * vpd_data, //forcing
                              double *co2_data,
                              double * vegemap,
                              
                              double year,
                              double jday,
                              double time,
                              
                              double * qflx_soi,  //soil evap
                              double * qflx_eveg, //canopy evap
                              double * qflx_tveg, //transpiration
                              double * qflx_Ecrit, //critical transpiration

                              double * qflx_infil, //precip after infiltration
                              char* parameterfile,
                                   CTest *trees);
    
#ifdef __cplusplus
}
#endif




//////////////Tai////////////////

///////initialize function, with parameter file, and map later on, NX NY



///////running time steps, need forcing, and pressure profile input; return ET term of each layer//////
///////canopy evap, transpiration and soil evap could be copied into the input array



///////destroy function///////













